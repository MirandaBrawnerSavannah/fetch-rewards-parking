package cogent.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingGarageApplicationTests {

	@Test
	void contextLoads() {
	}

}
